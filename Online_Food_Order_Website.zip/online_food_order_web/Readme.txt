Hello Guys...

Thank You for downloading my project. Hope you'll like this.
I am a Software Engineer, and I have a YouTube Channel named as "Coding Roman" please visit my channel and Subscribe my Channel if You Like.

DO as following...
Create a Database in XAMPP named as "on_rest_web" and create a table.
and Just Click on Import option from phpmyadmin and please select the .sql file....
and here you are ready with your website.

Thank You.. @codingroman