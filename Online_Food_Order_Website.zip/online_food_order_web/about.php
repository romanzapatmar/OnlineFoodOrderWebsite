<?php include('header.php')?>
<section class="ct1">
<div class="row">
   <center><h2 id="hd">Project Developed By</h2></center>
  <div class="column">
    <img class="cur" src="" alt="photo" height="250px" width="280px">
    <p class="det"><b>Name:</b>Mr. Viki T. Gondale <br><b>Mob. No.</b>7083146184 <br> <b>E-mail:</b>vikigondale@gmail.com</p>
  </div>
  <div class="column">
    <img class="cur" src="" alt="photo" height="250px" width="280px">
    <p class="det"><b>Name:</b>Mr. Romankumar S. Zapatmar <br><b>Mob. No.</b>7588411763 <br> <b>E-mail:</b>romanzapatmar123@gmail.com</p>
  </div>
  <div class="column">
    <img class="cur" src="i" alt="photo" height="250px" width="280px">
    <p class="det"><b>Name:</b>Mr. Roshan Bhajbhuje <br><b>Mob. No.</b>7875404526 <br> <b>E-mail:</b>roshanbhajbuje@gmail.com</p>
  </div>
  <div class="column" id="ph">
    <img class="cur" src="" alt="photo" height="250px" width="280px">
    <p class="det"><b>Name:</b>Mr. Aaquib J. Mohammad <br><b>Mob. No.</b>7887711892 <br> <b>E-mail:</b>mohammadaaquib901@gmail.com</p>
  </div>
</div>
</section>
<div class="intro">
<p id="intpara"><i>"Welcome to our website... We are glad to you for visiting here. we make project to experience you well in the world of web technologies. We feels honour to you visit here from the development group of Computer Science and Engineering Department"</i><p/><p id="ho">-HOD <br> Computer Science & Engineering Department <br> WCEM, Nagpur </p>
</div>
<?php include('footer.php')?>