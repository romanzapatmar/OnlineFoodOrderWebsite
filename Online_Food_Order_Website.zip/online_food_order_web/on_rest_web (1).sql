-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2022 at 10:07 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `on_rest_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `comments` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comments`) VALUES
(1, 'Tea Please'),
(4, 'Nice roman'),
(5, 'achi h website'),
(6, 'Nice website'),
(7, 'Nice WEBSITE'),
(8, 'Nice web'),
(9, 'Nice web'),
(10, 'Nice website'),
(11, 'review');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `cust_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pin_no` varchar(100) NOT NULL,
  `mob_no` varchar(100) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `cust_name`, `address`, `pin_no`, `mob_no`, `food_name`, `price`) VALUES
(15, 'Nitin', 'Deori', '441901', ' 3213265241', ' Noodles', 300),
(16, 'Shasipal', 'Nagpur', '441901', ' 1012012547', ' Tofurikka', 100),
(17, 'ROMANKUMAR SHATRUGHAN ZAPATMAR', 'Hanuman Chawk wardno1\r\nkakodi tah Deori Di Gondia', '441901', ' 3332655562', ' Noodles', 300),
(18, 'er', 'w', '441901', ' 3625636652', ' Panipuri', 299),
(20, 'Coding Roman', 'Nagpur', '221524', ' 3265554875', ' Dosa', 200),
(21, 'Ankit Madavi', 'Nagpur', '32164', ' 6543165894', ' Manchurian', 150),
(22, 'Roshan', 'Nagpur', '564874', ' 7854965555', ' Dosa', 200),
(23, 'Aaquib', 'Mumbai', '545632', ' 9586578452', ' Veg Biryani', 300),
(24, 'WCM', 'nagpur', '545456', ' 1524789658', ' Manchurian', 141),
(25, 'om', 'nagpur', '456123', ' 5858585456', ' Noodles', 126);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
