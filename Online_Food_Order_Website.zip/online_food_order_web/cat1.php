<?php include('header.php')?>

<section class="ct1">
  <center><h2>The Maharashtrian Food</h2></center>
<div class="row">
  <div class="column">
    <h4 id="h">Bade</h4>
    <img class="cur" src="image/bade.jpg" alt="" height="270px" width="300px">
    <p>Rs. 100</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
  <div class="column">
  <h4>Bhajiya</h4>
    <img class="cur" src="image/bhajiya.jpg" alt="" height="270px" width="300px">
    <p>Rs. 200</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
  <div class="column">
  <h4>Veg biryani</h4>
    <img class="cur" src="image/chin2.jpg" alt="" height="270px" width="300px">
    <p>Rs. 300</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
</div>
</section>
<!-- advertise -->
<section>
  <div class="adj1">
    <p id="o1">Best offer in Diwali 50% off</p><p id="o2">30% off for Family Dinner</p>
    <p id="o3">Celebration Hall Available</p><p id="o4">New offers waiting for you</p>
  </div>
</section>
<?php include('footer.php')?>