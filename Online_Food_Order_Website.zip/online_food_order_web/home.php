<?php include('header.php')?>

<h1 id="head">Welcome to our restaurant...</h1>
<div class="set">
    <div class="ps">
        <p id="bahot">The Breakfast Story is a one of a kind restaurant in Nagpur, which is well known for its all-day breakfasts. A lot of emphasis has been placed on the look and interiors of the restaurant, which features creative uses of recycled and second-hand goods to give a vibrant and cheerful look to the place. You’ll find shopping trolleys as newspaper stands to having games like snakes and ladder engraved on the furniture. The Breakfast Story changes its menu daily except for the egg dishes and the sides. Charming and quirky, The Breakfast Story is a great place to relax and have breakfast while reading the newspaper or chatting with friends.</p>
    </div>
    <div class="pc">
        <img id="fm" src="image/Home.jpg" alt="" width="400px" height="400px">
    </div>
</div>
<section class="ad1">
    <div class="menu">
    <img class="sid" src="image/bread.jpg" alt="" width="200">
    <img class="sid"  src="image/chin.jpg" alt="" width="200">
    <img class="sid"  src="image/chin1.jpg" alt="" width="200">
    <img class="sid"  src="image/chin2.jpg" alt="" width="200">
    <img class="sid"  src="image/dosa.jpg" alt="" width="200">
    <img class="sid"  src="image/kachori.jpg" alt="" width="200">
    <!-- <img class="sid"  src="image/bhel.jpg" alt="" width="200"> -->
   
    </div>
</section>
<!-- advertise -->
<section>
  <div class="adj1">
    <p id="o1">Best offer in Diwali 50% off</p><p id="o2">30% off for Family Dinner</p>
    <p id="o3">Celebration Hall Available</p><p id="o4">New offers waiting for you</p>
  </div>
</section>
<?php include('footer.php')?>