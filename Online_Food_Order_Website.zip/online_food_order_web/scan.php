<?php include('header.php')?>
<a id="back" href="order.php">Click for Back</a>
<center><h2>Scan here</h2></center>
<div class="scan">
    <img src="image/scan.png" alt="">
</div>
<?php include('footer.php')?>