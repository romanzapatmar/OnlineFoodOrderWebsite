<?php include('header.php')?>
<section>
<center><h2>The South Indian Food</h2></center>
<div class="row">
  <div class="column">
    <h4 id="mn">Dosa</h4>
    <img class="cur" src="image/dosa.jpg" alt="" height="270px" width="300px">
    <p>Rs. 150</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
  <div class="column">
  <h4>Family Meal</h4>
    <img class="cur" src="image/pic1.jpg" alt="" height="270px" width="300px">
    <p>Rs. 450</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
  <div class="column">
  <h4>Tofutikka</h4>
    <img class="cur" src="image/tofutikka.jpg" alt="" height="270px" width="300px">
    <p>Rs. 350</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
</div>
</section>
<!-- advertise -->
<section>
  <div class="adj1">
    <p id="o1">Best offer in Diwali 50% off</p><p id="o2">30% off for Family Dinner</p>
    <p id="o3">Celebration Hall Available</p><p id="o4">New offers waiting for you</p>
  </div>
</section>
<?php include('footer.php')?>