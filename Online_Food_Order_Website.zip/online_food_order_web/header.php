<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <!-- css -->
 <link rel="stylesheet" href="css/header.css">
 <link rel="stylesheet" href="css/footer.css">
 <link rel="stylesheet" href="css/contact.css">
 <link rel="stylesheet" href="css/about.css">
 <link rel="stylesheet" href="css/scan.css">
 <link rel="stylesheet" href="css/home.css">
 <link rel="stylesheet" href="css/cat1.css">
 <link rel="stylesheet" href="css/cat2.css">
 <link rel="stylesheet" href="css/cat3.css">
 <link rel="stylesheet" href="css/cat4.css">
 <link rel="stylesheet" href="css/order.css">
 
  <!-- title -->
  <title>Online Restaurant Food Order Website</title>
  <link rel="icon" href="image/logo.png" type="image/x-icon">
</head>
<body id="showcase">
<nav class="nav">
  <ul>
  <li><p id="on">Online Food Order Website</p></li>
      <li><a href="Home.php">Home</a></li>
      <div class="dropdown">
        <a href="" class="dropbtn">Categories</a>
            <div class="dropdown-content">
                <a href="cat1.php">Maharashtrian Food</a>
                <a href="cat2.php">Chinese Food</a>
                <a href="cat3.php">South Indian</a>
                <a href="cat4.php">Other</a>
            </div>
      </div>
      <li><a href="about.php">About us</a></li>
      <li><a href="contact.php">Contact us</a></li>
      
  </ul>
</nav>
  <marquee behavior="" direction="">Food Order Website</marquee>

