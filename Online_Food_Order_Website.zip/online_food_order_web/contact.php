<?php include('header.php')?>
<h1 id="ge">Get in touch with us...</h1>
<div class="set">
    <div class="ad">
        <address id="bahot">Near Green IT Park, New Delhi <br>
            Mob. 91XXXXXXXX <br>
            E-mail: codebeings@gmail.com
        </address>
    </div>
    <div class="pc">
        <img id="fm" src="image/contact.jpg" alt="" width="400px" height="400px">
    </div>
    
</div>
<!-- form -->
<!-- form code -->
<?php
include('conn.php');

if (isset($_POST['sub'])) {

  $com_ments = mysqli_real_escape_string($con, $_REQUEST['com']);
 

  $sql = "INSERT INTO `comments` (`comments`) VALUES ('$com_ments')";

  // echo $sql;

  $result = mysqli_query($con, $sql);

  if (!isset($result)) {
    echo "Not inserted!".mysqli_query_error();
  }
  // else{
  //   echo "Inserted successfully!";
  // }
if ($result) {
  echo "<script>
  alert('Thanks for comment!!!');
  </script>";
}
}

?>
<!-- form code -->
    <div class="comm">
<h4 id="lc">Leave Comment here...</h4> <br>
    <form role="form" method="POST" action="">
    <div class="form-group">
        <textarea name="com" class="form-control" id="com" cols="5" placeholder="suggest us..."></textarea>
        </div>
        <button  type="submit" class="btn btn-primary" name="sub" id="sub">Submit</button>
      </form>
    </div>
    <!-- section -->
    <section class="consec">

    </section>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    <?php include('footer.php')?>