<?php include('header.php')?>
<section>
<center><h2>The Chinese Food</h2></center>
<div class="row">
  <div class="column">
    <h4 id="mn">Manchurian</h4>
    <img class="cur" src="image/chin.jpg" alt="" height="270px" width="300px">
    <p class="pr">Rs. 100</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
  <div class="column">
  <h4>Noodles</h4>
    <img class="cur" src="image/chin1.jpg" alt="" height="270px" width="300px">
    <p class="pr">Rs. 200</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
  <div class="column">
  <h4>Veg biryani</h4>
    <img class="cur" src="image/vegbir.jpg" alt="" height="270px" width="300px">
    <p class="pr">Rs. 250</p>
    <button><a class="order" href="order.php">Order</a></button>
  </div>
</div>
</section>
<!-- advertise -->
<section>
  <div class="adj1">
    <p id="o1">Best offer in Diwali 50% off</p><p id="o2">30% off for Family Dinner</p>
    <p id="o3">Celebration Hall Available</p><p id="o4">New offers waiting for you</p>
  </div>
</section>
<?php include('footer.php')?>