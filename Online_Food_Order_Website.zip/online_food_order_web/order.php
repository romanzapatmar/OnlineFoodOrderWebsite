<?php include('header.php')?>
<a id="back" href="cat1.php">Click for Back</a>
<!-- place order -->
<?php 
 include('conn.php');

if (isset($_POST['submit'])) {

  $Cname = mysqli_real_escape_string($con, $_REQUEST['Cname']);
  $Address = mysqli_real_escape_string($con, $_REQUEST['Address']);
  $Pin = mysqli_real_escape_string($con, $_REQUEST['Pin']);
  $Mob = mysqli_real_escape_string($con, $_REQUEST['Mob']);
  $Fname = mysqli_real_escape_string($con, $_REQUEST['Fname']);
  $Price = mysqli_real_escape_string($con, $_REQUEST['Price']);

  $sql = "INSERT INTO `tbl_order`(`cust_name`, `address`, `pin_no`, `mob_no`, `food_name`, `price`) VALUES ('$Cname','$Address','$Pin',' $Mob',' $Fname',' $Price')";

  // echo $sql;

  $result = mysqli_query($con, $sql);

  if (!isset( $result )) {
    echo "Not inserted!".mysqli_query_error();
  }
  // else{
  //   echo "Inserted successfully!";
  // }
if ($result) {
  echo "<script>
  alert('Your order is place successfully!');
  </script>";
  // echo "Registration successfully!";
 
}
}

?>

<!-- place order -->
<div class="main">
  <div class="register">
   <center><h3 id="or">Order here...</h3></center>
    <form action="" Method="POST" autocomplete="off">
      <input type="text" placeholder="Enter Your Name" id="Cname" name="Cname" required="true">
      <br>
      <textarea name="Address" placeholder="Enter your address" id="Address" cols="30" rows="10" required="true"></textarea>
      <br>
      <input type="number" pattern="^\d{6}$" placeholder="PIN Code" name="Pin" id="Pin">
      <br>
      <input type="Mobile No." pattern="^\d{10}$" placeholder="Mobile no" name="Mob" id="Mob" required="true">
      <br>
      <select name="Fname" id="Fname" required="true">
        <option value="">---Select Food---</option>
        <option value="Samosa">Samosa</option>
        <option value="Veg Biryani">Veg Biryani</option>
        <option value="Kachori">Kachori</option>
        <option value="Idli">Idli</option>
        <option value="Panipuri">Panipuri</option>
        <option value="Dosa">Dosa</option>
        <option value="Noodles">Noodles</option>
        <option value="Manchurian">Manchurian</option>
        <option value="Tofurikka">Tofurikka</option>
      </select>
      <br>
      
      <input type="number" min="50" max="500" name="Price" placeholder="Enter Price" id="Price" required="true">
      <a id="payon" href="scan.php">Pay Online</a>
      <br>
     
      <button type="submit" name="submit" id="submit">Place Order</button>
     
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
<?php include('footer.php')?>